import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _e647480a = () => interopDefault(import('..\\pages\\join.vue' /* webpackChunkName: "pages_join" */))
const _2ba08f40 = () => interopDefault(import('..\\pages\\notfound.vue' /* webpackChunkName: "pages_notfound" */))
const _fc94a182 = () => interopDefault(import('..\\pages\\design\\_url.vue' /* webpackChunkName: "pages_design__url" */))
const _788bbee2 = () => interopDefault(import('..\\pages\\hangjia\\_index.vue' /* webpackChunkName: "pages_hangjia__index" */))
const _02be4f5e = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages_index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/join",
    component: _e647480a,
    name: "join"
  }, {
    path: "/notfound",
    component: _2ba08f40,
    name: "notfound"
  }, {
    path: "/design/:url?",
    component: _fc94a182,
    name: "design-url"
  }, {
    path: "/hangjia/:index",
    component: _788bbee2,
    name: "hangjia"
  }, {
    path: "/",
    component: _02be4f5e,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
